=== Theme: Th-Store ===
Contributors: ThemeHunk
Tags: e-commerce, blog, grid-layout, one-column, two-columns, three-columns, four-columns, left-sidebar, right-sidebar, custom-background, custom-colors, custom-logo, custom-menu, featured-image-header, featured-images, custom-header, footer-widgets, full-width-template, sticky-post, theme-options, threaded-comments, translation-ready, threaded-comments, custom-colors 
Requires at least: 4.5
Tested up to: 5.8.1
Stable tag: 1.0.3
License: GPLv3 or later
License URL: https://www.gnu.org/licenses/gpl-3.0.en.html

"Th-Store is a child theme of Big Store WordPress theme" By Big Store.

== Description ==
Th-store is a wonderful child theme of Big store and Big store pro. It is Best suited for websites like gadget store, home appliances site, fashion shop, furniture, jewelry shop, electronic, food, grocery, clothing etc. Theme is deeply integrated with WooCommerce plugin to sell your products online. Theme has many sections along with Header and footer layout combinations, Color and Background option and other customizing options.


== Frequently Asked Questions ==

= Does your theme works with latest WordPress version. =
Yes, our theme works with latest WordPress version.

= Does your theme support third party plugin =
Yes, we have created our theme in such a way that it can support almost all plugin available in a market. However, It is very difficult to test each and every plugin. So if you get any issues either you can contact to our support forum. They will help you in every possible manner to make plugin compatible with the theme. Or you can use any alternate plugin.

= Does your theme works on multisite. =
Yes, all our theme works on multisite.
  
== Resources ==

WordPress theme "Th-Store" is a child theme of "Big Store".
Big Store Theme is licensed under the GPL3.

== License ==
Image License:
https://stocksnap.io/photo/urban-fashion-EIZQNPK7VM
Licensed under the CCO license.

== Changelog ==

== 1.0.3  =
* Th advance product search plugin added.

== 1.0.2  =
* Search issue fixed

== 1.0.1  =
* New header layout added.
* New footer layout added.
* Contact form 7 style added.

== 1.0.0  =
* Initial release
Once again, thank you so much for trying the Th-Store WordPress Theme. As we said at the beginning, we will be glad to help you. If you have any questions related to this theme then do let us know & we will try our best to assist. If you have any general questions related to the themes on Big Store, we would recommend you to visit the our Support Forum https://themehunk.com/support/ and ask your queries there.


