jQuery(document).ready(function(){
jQuery('input[id=big_store_main_header_layout-mhdrdefault],input[id=big_store_bottom_footer_widget_layout-ft-wgt-five]').prop('disabled', false);
});