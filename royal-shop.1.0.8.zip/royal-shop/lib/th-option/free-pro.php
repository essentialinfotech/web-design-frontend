  <div class="th-dashboard">
      <div class="content free-pro">
            <table class="table">
               <tbody class="table-body">
                  <tr class="table-head">
                     <th class="title" align="left"><?php _e('Features','royal-shop'); ?></th>
                     <th class="status" align="center"><?php _e('Royal Shop','royal-shop'); ?> </th>
                     <th class="status" align="center"><?php _e('Royal Shop Pro','royal-shop'); ?> </th>
                  </tr>

                  <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4><?php _e('Section Hide Option','royal-shop'); ?> </h4>
                        </div>
                     </td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span></td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span></td>
                  </tr>

                  <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4><?php _e('Footer Layout','royal-shop'); ?> </h4>
                        </div>
                     </td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span>

                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span>

                  </tr>


                  <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4><?php _e('Full Color & Background Control','royal-shop'); ?> </h4>
                        </div>
                     </td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span><span class="info"><?php _e('(Basic)','royal-shop'); ?> </span></td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span><span class="info"><?php _e('(Advanced)','royal-shop'); ?> </span></td>
                  </tr>

                  <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4><?php _e('Frontpage Header Slider','royal-shop'); ?> </h4>
                        </div>
                     </td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span>

                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span>

                  </tr>


                  <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4><?php _e('Ribbon Section','royal-shop'); ?> </h4>
                        </div>
                     </td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span>
                        </td>

                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span><span class="info"><?php _e('(Image & Video)','royal-shop'); ?> </span>
                        </td>

                  </tr>




                  <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4><?php _e('Tabbed Product Carousel Section','royal-shop'); ?> </h4>
                        </div>
                     </td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span>

                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span>

                  </tr>


                  <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4><?php _e('Product Carousel Section','royal-shop'); ?> </h4>
                        </div>
                     </td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span>

                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span>

                  </tr>


                  <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4><?php _e('Woo Category Section ','royal-shop'); ?> </h4>
                        </div>
                     </td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span><span class="info"><?php _e('(One Layout)','royal-shop'); ?> </span></td>

                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span><span class="info"><?php _e('(Three Layout)','royal-shop'); ?> </span></td>

                  </tr>




                   <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4><?php _e('Product List Carousel Section','royal-shop'); ?> </h4>
                        </div>
                     </td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span>
                        </td>

                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span>
                     </td>

                  </tr>


                  <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4><?php _e('Banner Section  ','royal-shop'); ?> </h4>
                        </div>
                     </td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span>
                        <span class="info"><?php _e('(Two Layouts)','royal-shop'); ?> </span></td>

                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span>
                        <span class="info"><?php _e('(Six Layouts)','royal-shop'); ?> </span></td>

                  </tr>

                    <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4><?php _e('Highlight Section  ','royal-shop'); ?> </h4>
                        </div>
                     </td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span>
                     </td>

                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span>
                     </td>

                  </tr>

                  <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4><?php _e('Move to top','royal-shop'); ?> </h4>
                        </div>
                     </td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span>
                        </td>

                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span>
                        </td>

                  </tr>


                  <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4><?php _e('Fully Responsive','royal-shop'); ?> </h4>
                        </div>
                     </td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span>
                        </td>

                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span>
                        </td>

                  </tr>

                  <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4><?php _e('Social Icons','royal-shop'); ?> </h4>
                        </div>
                     </td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span>
                        </td>

                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span>
                        </td>

                  </tr>


                  <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4><?php _e('Ajax Search','royal-shop'); ?> </h4>
                        </div>
                     </td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span>
                        </td>

                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span>
                        </td>

                  </tr>


                   <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4><?php _e('Pre loader','royal-shop'); ?> </h4>
                        </div>
                     </td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span>
                        </td>

                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span>
                        </td>

                  </tr>


                   <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4><?php _e('Blog page setting','royal-shop'); ?> </h4>
                        </div>
                     </td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span>
                        </td>

                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span>
                        </td>

                  </tr>



                  <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4><?php _e('Pagination option ( Shop Page, Blog Page)','royal-shop'); ?> </h4>
                        </div>
                     </td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span><span class="info"><?php _e('(Numbered)','royal-shop'); ?> </span>
                        </td>

                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span><span class="info"><?php _e('(Numbered, Load More, Infinite Scroll)','royal-shop'); ?> </span>
                        </td>

                  </tr>


                   <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4><?php _e('Product Quick View','royal-shop'); ?> </h4>
                        </div>
                     </td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span>
                        </td>

                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span>
                        </td>

                  </tr>






                  <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4><?php _e('Product Image Hover Style','royal-shop'); ?> </h4>
                        </div>
                     </td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span><span class="info"><?php _e('(Zoom )','royal-shop'); ?> </span>
                        </td>

                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span><span class="info"><?php _e('(Zoom, Swap and Swap Slide)','royal-shop'); ?> </span>
                     </td>

                  </tr>


                  <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4><?php _e('Post Slide Widget','royal-shop'); ?> </h4>
                        </div>
                     </td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span>
                        </td>

                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span>
                     </td>

                  </tr>




                  <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4><?php _e('Support','royal-shop'); ?> </h4>
                        </div>
                     </td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span>
                        <span class="info"><?php _e('(Basic)','royal-shop'); ?> </span></td>

                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span>
                     <span class="info"><?php _e('(Priority)','royal-shop'); ?> </span></td>

                  </tr>








                  <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4> <?php _e('Section Ordering','royal-shop'); ?> </h4>
                        </div>
                     </td>
                     <td class="status error"><span class="dashicon dashicons dashicons-no-alt" size="30"></span></td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span></td>
                  </tr>


                  <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4> <?php _e('Four Custom Section','royal-shop'); ?> </h4>
                        </div>
                     </td>
                     <td class="status error"><span class="dashicon dashicons dashicons-no-alt" size="30"></span></td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span></td>
                  </tr>


                  <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4> <?php _e('Big Featured Product Section','royal-shop'); ?> </h4>
                        </div>
                     </td>
                     <td class="status error"><span class="dashicon dashicons dashicons-no-alt" size="30"></span></td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span></td>
                  </tr>


                  <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4> <?php _e('Brand Section','royal-shop'); ?> </h4>
                        </div>
                     </td>
                     <td class="status error"><span class="dashicon dashicons dashicons-no-alt" size="30"></span></td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span></td>
                  </tr>


                  <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4> <?php _e('Tabbed Product Image Carousel Section','royal-shop'); ?> </h4>
                        </div>
                     </td>
                     <td class="status error"><span class="dashicon dashicons dashicons-no-alt" size="30"></span></td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span></td>
                  </tr>


                  <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4> <?php _e('Tabbed Product list Carousel Section','royal-shop'); ?> </h4>
                        </div>
                     </td>
                     <td class="status error"><span class="dashicon dashicons dashicons-no-alt" size="30"></span></td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span></td>
                  </tr>


                   <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4> <?php _e('Single Product Slide Widget','royal-shop'); ?> </h4>
                        </div>
                     </td>
                     <td class="status error"><span class="dashicon dashicons dashicons-no-alt" size="30"></span></td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span></td>
                  </tr>


                  <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4> <?php _e('Tabbed Product Widget','royal-shop'); ?> </h4>
                        </div>
                     </td>
                     <td class="status error"><span class="dashicon dashicons dashicons-no-alt" size="30"></span></td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span></td>
                  </tr>


                  <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4> <?php _e('Testimonial Widget','royal-shop'); ?> </h4>
                        </div>
                     </td>
                     <td class="status error"><span class="dashicon dashicons dashicons-no-alt" size="30"></span></td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span></td>
                  </tr>



                  <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4> <?php _e('Vertical Tabbed Product Widget','royal-shop'); ?> </h4>
                        </div>
                     </td>
                     <td class="status error"><span class="dashicon dashicons dashicons-no-alt" size="30"></span></td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span></td>
                  </tr>

                  
                    <tr class="feature-row th-buy-pro">
                     <td class="title">
                        <div class="title-wrap">
                           <h4><?php _e('Pro Theme','royal-shop'); ?> </h4>
                        </div>
                     </td>
                     <td class="status upsell"><?php _e('Access to all Pro features','royal-shop'); ?> </td>
                     <td class="status success"><a href="<?php echo esc_url('https://themehunk.com/product/royal-shop/');?>" target="_blank" rel="external noreferrer noopener" class="components-button is-primary"><?php _e('Get Royal Shop Pro Now','royal-shop'); ?></a></td>
                  </tr>



               </tbody>
            </table>
      </div>
   </div>
