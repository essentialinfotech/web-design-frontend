<?php
/**
 * Header Options for  Royal Shop Theme.
 *
 * @package      Royal Shop
 * @author       Royal Shop
 * @since        Royal Shop 1.0.0
 */
$wp_customize->get_control( 'header_image' )->section = 'royal-shop-abv-header-clr';
$wp_customize->get_control( 'header_image' )->priority = 1;
