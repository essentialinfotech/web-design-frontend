<?php
/**
 * Header Options for  M ShopTheme.
 *
 * @package      M Shop
 * @author       M Shop
 * @since        M Shop1.0.0
 */
$wp_customize->get_control( 'header_image' )->section = 'm-shop-main-header-clr';
$wp_customize->get_control( 'header_image' )->priority = 2;
