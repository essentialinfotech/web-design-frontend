/**
 * Button control in customizer
 *
 * @package M Shop
 */
wp.customize.controlConstructor['m-shop-buttonset'] = wp.customize.Control.extend({
	ready: function() {
		'use strict';
		var control = this;
		// Change the value
		this.container.on( 'click', 'input', function() {
			control.setting.set( jQuery( this ).val() );
		});
	}

});

