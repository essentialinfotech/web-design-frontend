<?php
define('M_SHOP_TOP_HEADER_LAYOUT_1', M_SHOP_THEME_URI. "customizer/images/top-header-1.png");
define('M_SHOP_TOP_HEADER_LAYOUT_2', M_SHOP_THEME_URI. "customizer/images/top-header-2.png");
define('M_SHOP_TOP_HEADER_LAYOUT_3', M_SHOP_THEME_URI. "customizer/images/top-header-3.png");
define('M_SHOP_TOP_HEADER_LAYOUT_NONE', M_SHOP_THEME_URI. "customizer/images/top-header-none.png");

define('M_SHOP_MAIN_HEADER_LAYOUT_ONE', M_SHOP_THEME_URI. "customizer/images/header-layout-1.png");
define('M_SHOP_MAIN_HEADER_LAYOUT_TWO', M_SHOP_THEME_URI. "customizer/images/header-layout-2.png");
define('M_SHOP_MAIN_HEADER_LAYOUT_THREE', M_SHOP_THEME_URI. "customizer/images/header-layout-3.png");
define('M_SHOP_MAIN_HEADER_LAYOUT_FOUR', M_SHOP_THEME_URI. "customizer/images/header-layout-4.png");

define('M_SHOP_FOOTER_WIDGET_LAYOUT_1', M_SHOP_THEME_URI. "customizer/images/widget-footer-1.png");
define('M_SHOP_FOOTER_WIDGET_LAYOUT_2', M_SHOP_THEME_URI. "customizer/images/widget-footer-2.png");
define('M_SHOP_FOOTER_WIDGET_LAYOUT_3', M_SHOP_THEME_URI. "customizer/images/widget-footer-3.png");
define('M_SHOP_FOOTER_WIDGET_LAYOUT_4', M_SHOP_THEME_URI. "customizer/images/widget-footer-4.png");
define('M_SHOP_FOOTER_WIDGET_LAYOUT_5', M_SHOP_THEME_URI. "customizer/images/widget-footer-5.png");
define('M_SHOP_FOOTER_WIDGET_LAYOUT_6', M_SHOP_THEME_URI. "customizer/images/widget-footer-6.png");
define('M_SHOP_FOOTER_WIDGET_LAYOUT_7', M_SHOP_THEME_URI. "customizer/images/widget-footer-7.png");
define('M_SHOP_FOOTER_WIDGET_LAYOUT_8', M_SHOP_THEME_URI. "customizer/images/widget-footer-8.png");
define('M_SHOP_FOOTER_WIDGET_LAYOUT_NONE', M_SHOP_THEME_URI. "customizer/images/widget-footer-none.png");
//SLIDER
define('M_SHOP_SLIDER_LAYOUT_1', M_SHOP_THEME_URI. "customizer/images/slider-layout-1.png");
define('M_SHOP_SLIDER_LAYOUT_2', M_SHOP_THEME_URI. "customizer/images/slider-layout-2.png");
define('M_SHOP_SLIDER_LAYOUT_3', M_SHOP_THEME_URI. "customizer/images/slider-layout-3.png");
define('M_SHOP_SLIDER_LAYOUT_4', M_SHOP_THEME_URI. "customizer/images/slider-layout-4.png");
define('M_SHOP_SLIDER_LAYOUT_5', M_SHOP_THEME_URI. "customizer/images/slider-layout-5.png");
define('M_SHOP_SLIDER_LAYOUT_6', M_SHOP_THEME_URI. "customizer/images/slider-layout-6.png");
//category slider
define('M_SHOP_CAT_SLIDER_LAYOUT_1', M_SHOP_THEME_URI. "customizer/images/category-slider-1.png");
define('M_SHOP_CAT_SLIDER_LAYOUT_2', M_SHOP_THEME_URI. "customizer/images/category-slider-2.png");
define('M_SHOP_CAT_SLIDER_LAYOUT_3', M_SHOP_THEME_URI. "customizer/images/category-slider-3.png");
//Banner Slider
define('M_SHOP_BANNER_IMG_LAYOUT_1', M_SHOP_THEME_URI. "customizer/images/banner-image-1.png");
define('M_SHOP_BANNER_IMG_LAYOUT_2', M_SHOP_THEME_URI. "customizer/images/banner-image-2.png");
define('M_SHOP_BANNER_IMG_LAYOUT_3', M_SHOP_THEME_URI. "customizer/images/banner-image-3.png");
define('M_SHOP_BANNER_IMG_LAYOUT_4', M_SHOP_THEME_URI. "customizer/images/banner-image-4.png");
define('M_SHOP_BANNER_IMG_LAYOUT_5', M_SHOP_THEME_URI. "customizer/images/banner-image-5.png");
define('M_SHOP_BANNER_IMG_LAYOUT_6', M_SHOP_THEME_URI. "customizer/images/banner-image-6.png");
//Custom section
define('M_SHOP_CUSTOM_LAYOUT_1', M_SHOP_THEME_URI. "customizer/images/widget-footer-1.png");
define('M_SHOP_CUSTOM_LAYOUT_2', M_SHOP_THEME_URI. "customizer/images/widget-footer-2.png");
define('M_SHOP_CUSTOM_LAYOUT_3', M_SHOP_THEME_URI. "customizer/images/widget-footer-3.png");


define('M_SHOP_ABOUT_IMG_1', M_SHOP_THEME_URI. "image/founder.png");
