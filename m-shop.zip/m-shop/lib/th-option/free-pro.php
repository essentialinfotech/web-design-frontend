  <div class="th-dashboard">
      <div class="content free-pro">
            <table class="table">
               <tbody class="table-body">
                  <tr class="table-head">
                     <th class="title" align="left"><?php _e('Features','m-shop'); ?></th>
                     <th class="status" align="center"><?php _e('M Shop','m-shop'); ?> </th>
                     <th class="status" align="center"><?php _e('M Shop Pro','m-shop'); ?> </th>
                  </tr>

                  <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4><?php _e('Section Hide Option','m-shop'); ?> </h4>
                        </div>
                     </td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span></td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span></td>
                  </tr>

                  
                  
                  <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4><?php _e('Side Pan','m-shop'); ?> </h4>
                        </div>
                     </td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span></td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30">
                     </span></td>



                  <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4><?php _e('Footer Layout','m-shop'); ?> </h4>
                        </div>
                     </td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span>

                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span>

                  </tr>


                  <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4><?php _e('Full Color & Background Control','m-shop'); ?> </h4>
                        </div>
                     </td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span><span class="info"><?php _e('(Basic)','m-shop'); ?> </span></td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span><span class="info"><?php _e('(Advanced)','m-shop'); ?> </span></td>
                  </tr>


                    <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4><?php _e('Top Slider Section','m-shop'); ?> </h4>
                        </div>
                     </td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span><span class="info"><?php _e('(Two Layouts)','m-shop'); ?> </span></td>

                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span><span class="info"><?php _e('(Six Layouts)','m-shop'); ?> </span></td>

                  </tr>



                  <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4><?php _e('Tabbed Product Carousel Section','m-shop'); ?> </h4>
                        </div>
                     </td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span>

                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span>

                  </tr>


                  <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4><?php _e('Woo Category Section','m-shop'); ?> </h4>
                        </div>
                     </td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span>
                        <span class="info"><?php _e('(One Layouts)','m-shop'); ?> </span></td>

                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span>
                        <span class="info"><?php _e('(Three Layouts)','m-shop'); ?> </span></td>

                  </tr>


                   <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4><?php _e('Product List Carousel Section','m-shop'); ?> </h4>
                        </div>
                     </td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span>
                        </td>

                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span>
                     </td>

                  </tr>


                   <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4><?php _e('Banner Section','m-shop'); ?> </h4>
                        </div>
                     </td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span>
                        <span class="info"><?php _e('(Two Layouts)','m-shop'); ?> </span></td>

                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span>
                        <span class="info"><?php _e('(Four Layouts)','m-shop'); ?> </span></td>

                  </tr>


                   <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4><?php _e('Highlight Section','m-shop'); ?> </h4>
                        </div>
                     </td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span></td>

                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span></td>

                  </tr>



                  <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4><?php _e('Product Quick View','m-shop'); ?> </h4>
                        </div>
                     </td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span>
                        </td>

                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span>
                     </td>

                  </tr>




                  <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4><?php _e('Support','m-shop'); ?> </h4>
                        </div>
                     </td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span>
                        <span class="info"><?php _e('(Basic)','m-shop'); ?> </span></td>

                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span>
                     <span class="info"><?php _e('(Priority)','m-shop'); ?> </span></td>

                  </tr>








                  <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4> <?php _e('Section Ordering','m-shop'); ?> </h4>
                        </div>
                     </td>
                     <td class="status error"><span class="dashicon dashicons dashicons-no-alt" size="30"></span></td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span></td>
                  </tr>


                  <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4> <?php _e('Four Custom Section','m-shop'); ?> </h4>
                        </div>
                     </td>
                     <td class="status error"><span class="dashicon dashicons dashicons-no-alt" size="30"></span></td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span></td>
                  </tr>


                  <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4> <?php _e('Off Canvas Sidebar','m-shop'); ?> </h4>
                        </div>
                     </td>
                     <td class="status error"><span class="dashicon dashicons dashicons-no-alt" size="30"></span></td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span></td>
                  </tr>


                  <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4> <?php _e('Single Product Carousel','m-shop'); ?> </h4>
                        </div>
                     </td>
                     <td class="status error"><span class="dashicon dashicons dashicons-no-alt" size="30"></span></td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span></td>
                  </tr>


                  <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4> <?php _e('Brand Section','m-shop'); ?> </h4>
                        </div>
                     </td>
                     <td class="status error"><span class="dashicon dashicons dashicons-no-alt" size="30"></span></td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span></td>
                  </tr>


                  <tr class="feature-row">
                     <td class="title">
                        <div class="title-wrap">
                           <h4> <?php _e('Tabbed Product list Carousel Section','m-shop'); ?> </h4>
                        </div>
                     </td>
                     <td class="status error"><span class="dashicon dashicons dashicons-no-alt" size="30"></span></td>
                     <td class="status success"><span class="dashicon dashicons dashicons-yes" size="30"></span></td>
                  </tr>
                  
                    <tr class="feature-row th-buy-pro">
                     <td class="title">
                        <div class="title-wrap">
                           <h4><?php _e('Pro Theme','m-shop'); ?> </h4>
                        </div>
                     </td>
                     <td class="status upsell"><?php _e('Access to all Pro features','m-shop'); ?> </td>
                     <td class="status success"><a href="https://themehunk.com/product/m-shop-pro/" target="_blank" rel="external noreferrer noopener" class="components-button is-primary"><?php _e('Get M Shop Pro Now','m-shop'); ?></a></td>
                  </tr>



               </tbody>
            </table>
      </div>
   </div>
